using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Otzivi.Views.SecurityQuestion
{
    public class VerifyModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

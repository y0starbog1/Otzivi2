using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Otzivi.Views.Account
{
    public class SetSecurityQuestionModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Otzivi.Views.Shared
{
    public class _LoginPartialModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

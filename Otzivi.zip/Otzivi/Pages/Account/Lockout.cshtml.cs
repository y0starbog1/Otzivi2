using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Otzivi.Pages.Account
{
    public class LockoutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}